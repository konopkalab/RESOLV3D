# animate
# This script will
# - load the RData created by another function
# - create an animation of 3D scatter plot for better visualization
# - save animation as GIF file
#
# Build and Reload Package:  'Cmd + Shift + B'
# Check Package:             'Cmd + Shift + E'
# Test Package:              'Cmd + Shift + T'
# R --max-ppsize 500000

animate<-function(animateprefix)
{
  cat("===> Creating animation...", "\n")

  ## Loading packages
  suppressPackageStartupMessages({
    library(plot3D)
    library(rgl)
  })

  ## Loading previously saved RData
  lnames <- load("clustercells.RData")

  ## Rearranging data
  pp <- as.data.frame(cbind(seq(1, optimalclusters), table(expData4[,1]), colpalette))
  colnames(pp) <- c("Cluster", "Count", "Color")
  zz <- merge(pp, expData4, by="Cluster", all=TRUE)

  ## Creating a directory for animation and related images
  dirname <- paste("animation", animateprefix, sep="_")
  system(paste("mkdir", dirname, sep=" "))
  setwd(paste(dirname, "/", sep=""))

  ## Creating 3D scatter plot png images
  #r3dDefaults$windowRect<-c(0,50, 1000, 1000)
  par3d(windowRect = c(100, 100, 1000, 1000))

  plot3d(x=zz$X, y=zz$Y, z=zz$Z, col=zz$Color, type="p", size=15, xlab="X", ylab="Y", zlab="Z")
  for (i in 1:90)
  {
    view3d(userMatrix=rotationMatrix(2*pi * i/90, 0, 1, 0))
    rgl.snapshot(filename=paste("frame-", sprintf("%03d", i), ".png", sep=""))
  }

  ## Converting png images to gif animation
  ofn <- paste(animateprefix, "animated.gif", sep="_")
  system(paste("convert -delay 5 -loop 0 frame*.png", ofn, sep=" "))

  system("cp ./*animated.gif ./../")
  cat("===> GIF saved to directory:", paste("animation", animateprefix, sep="_"), "\n")
  setwd("./../")
}
