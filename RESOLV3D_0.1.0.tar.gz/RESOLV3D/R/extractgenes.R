# extractgenes
# This script will
# - seperate cells as per cluster
# - identify genes enriched in each cluster
# - perform spearman correlation to identify significantly highly correlated genes per cluster
# - report top genes per cluster

# Build and Reload Package:  'Cmd + Shift + B'
# Check Package:             'Cmd + Shift + E'
# Test Package:              'Cmd + Shift + T'
# R --max-ppsize 500000

extractgenes <- function(clusterData)
{
  cat("===> Extracting cluster-specific genes...", "\n")

  ## Loading packages
  suppressPackageStartupMessages({
    library(Hmisc)
    library(pheatmap)
  })

  ## Custom function definition to flatten the correlation matrix
  flattenCorrMatrix <- function(cormat, pmat)
  {
    ut<-upper.tri(cormat)
    data.frame(
      row=rownames(cormat)[row(cormat)[ut]],
      column=rownames(cormat)[col(cormat)[ut]],
      cor=(cormat)[ut],
      p=pmat[ut]
    )
  }

  ## Custom function definition to extract genes per cluster
  getGenes <- function(cluster, newData1, cellspergene, allData)
  {
    newData2 <- as.matrix(t(newData1))
    newData3 <- newData2

    expStatus <- as.data.frame(apply(newData3, 1, function(x) { table(x >= 0.5)["TRUE"]}))
    expStatus[is.na(expStatus)] <- 0
    names(expStatus) <- "ExpStatus"

    newData4 <- merge(expStatus, newData3, by="row.names")
    newData5 <- newData4[,-1]
    row.names(newData5) <- newData4[,1]

    newData6 <- merge(cellspergene, newData5, by="row.names")
    newData7 <- newData6[,-1]
    row.names(newData7) <- newData6[,1]

    # data to be used
    newData81 <- newData7[newData7[,1] < 0.5*max(newData7[,1]) & newData7[,2] >= 0.5*max(newData7[,2]),]
    newData81list <- as.vector(row.names(newData81))

    newData82 <- newData7[newData7[,1] < 0.25*max(newData7[,1]) & newData7[,2] >= 0.25*max(newData7[,2]),]
    newData82list <- as.vector(row.names(newData82))

    newData83 <- newData7[newData7[,1] < 0.75*max(newData7[,1]) & newData7[,2] >= 0.75*max(newData7[,2]),]
    newData83list <- as.vector(row.names(newData83))

    newData8list <- unique(sort(as.vector(c(newData81list, newData82list, newData83list))))
    newData8 <- newData7[newData8list,]

    newData9 <- newData8[order(newData8[,2], decreasing=T),]

    pdf(paste("cluster", cluster, "enrichedGenes.pdf", sep="_"), height=6, width=6)
    plot(newData7[,1], newData7[,2], pch=20, cex=1.2, col="grey", xlab="all cells", ylab="cells in this cluster", main=paste("Cluster", cluster, sep=" "), xlim=c(0, nrow(allData)), ylim=c(0, nrow(newData1)))
    par(new=T)
    plot(newData8[,1], newData8[,2], pch=20, cex=1.2, col="green", xlab="", ylab="", main="", xlim=c(0, nrow(allData)), ylim=c(0, nrow(newData1)))
    abline(h=0.5*max(newData7[,1]), lty=2, col="grey20")
    abline(v=0.5*max(newData7[,1]), lty=2, col="grey20")
    abline(v=0.75*max(newData7[,1]), lty=2, col="grey20")
    abline(v=0.25*max(newData7[,1]), lty=2, col="grey20")
    abline(h=0.25*max(newData7[,2]), lty=2, col="grey20")
    abline(h=0.5*max(newData7[,2]), lty=2, col="grey20")
    abline(h=0.75*max(newData7[,2]), lty=2, col="grey20")
    dev.off()

    #newData8 <- newData7[newData7[,1] > nrow(allData)*0.33*2 & newData7[,2] > nrow(newData1)*0.33*2,]
    #newData9 <- newData7[newData7[,1] < nrow(allData)*0.33*2 & newData7[,2] >= nrow(newData1)*0.33*2,]
    #newData9 <- na.omit(newData9)

    #pdf(paste("cluster", cluster, "enrichedGenes.pdf", sep="_"), height=6, width=6)
    #plot(newData7[,1], newData7[,2], pch=20, cex=1.2, col="grey", xlab="all cells", ylab="cells in this cluster", main=paste("Cluster", cluster, sep=" "), xlim=c(0, nrow(allData)), ylim=c(0, nrow(newData1)))
    #par(new=T)
    #plot(newData8[,1], newData8[,2], pch=20, cex=1.2, col="red", xlab="", ylab="", xlim=c(0, nrow(allData)), ylim=c(0, nrow(newData1)))
    #par(new=T)
    #plot(newData9[,1], newData9[,2], pch=20, cex=1.2, col="green", xlab="", ylab="", xlim=c(0, nrow(allData)), ylim=c(0, nrow(newData1)))
    #dev.off()

    cor_sig <- rcorr(t(newData9[,-c(1:2)]), type="spearman")
    data_cor <- flattenCorrMatrix(cor_sig$r, cor_sig$P)
    data_cor2 <- data_cor[data_cor$p <= 0.05,]
    corfilter <- 0.4
    data_cor3 <- data_cor2[data_cor2$cor >= corfilter | data_cor2$cor <= -corfilter,]
    data_cor4 <- data_cor3[order(data_cor3$cor, decreasing=T),]
    templist <- c(as.character(data_cor4$row), as.character(data_cor4$column))
    geneslist <- unique(templist)

    #cat("\t", "\t", length(geneslist), "correlated gene extracted for cluster", i, "\n")

    newData10 <- newData9[geneslist,]
    wmean <- newData10[,2] * apply(newData10[,-c(1:2)], 1, mean)
    newData11 <- cbind(wmean, newData10[,-c(1:2)])
    newData12 <- newData11[order(newData11[,1], decreasing=T),]

    write.table(row.names(newData12), paste("genes_cluster", cluster, "postCor_genes.txt", sep="_"), quote=F, row.names=F, col.names=F)
    write.table(row.names(newData12[1:50,]), paste("genes_cluster", cluster, "postCor_genes_top50.txt", sep="_"), quote=F, row.names=F, col.names=F)

    save(newData7, newData9, newData12, file=paste("cluster_", i, ".RData", sep=""))
  }

  ## This function starts from here
  ## Create a directory for gene extraction
  system("mkdir extractGenes")
  setwd("extractGenes")

  ## Sorting the data based on assigned cluster
  clusterData1 <- clusterData[order(clusterData[,1], decreasing=F),]

  ## number of cells the gene is expressed in
  cellsPerGene <- as.data.frame(apply(clusterData1[,-c(1:4)], 2, function(x) { table(x >= 0.5)["TRUE"]} ))
  cellsPerGene[is.na(cellsPerGene)] <- 0
  names(cellsPerGene) <- "CellsPerGene"

  ## Loop extract genes for all clusters one at a time
  for (i in 1:max(clusterData1[,1]))
  {
    cat("\t", "Processing cluster:", i, "\n")
    getGenes(i, clusterData1[clusterData1[,1] == i,-c(1:4)], cellsPerGene, clusterData1)
  }

  system("cp ./*top50.txt ./../")
  cat("===> Cluster-specific gene lists saved...", "\n")
  setwd("./../")
}
