# validatedata
# This script will
# - read the input data
# - identify number of rows and columns
# - identify if rows are genes or cells and transpose data if needed
# - remove cells with no gene expressed
# - remove genes not expressed in at least one cell
# - saves original and filtered data into RData
# - returns filtered data matrix
#
# Build and Reload Package:  'Cmd + Shift + B'
# Check Package:             'Cmd + Shift + E'
# Test Package:              'Cmd + Shift + T'
# R --max-ppsize 500000

validatedata <- function(inputdata, outprefix, expcutoff)
{
  cat("===> Running data validation...", "\n")

  ## Loading packages
  suppressPackageStartupMessages({
    library(ggplot2)
  })

  ## Reading input data
  cat("\t", "Reading input data...", "\n")
  datExpr <- read.table(inputdata, sep="\t", header=T, row.names=1)

  ## Identifying & transforming to check if rows are cells and columns are genes
  hkgene <- "Actb|ACTB"
  #grepl(hkgene, row.names(datExpr))
  rstatus <- table(grepl(hkgene, row.names(datExpr)))["TRUE"]
  rstatus[is.na(rstatus)] <- 0
  ifelse(rstatus >= 1, datExpr1 <- as.data.frame(t(datExpr)), datExpr1 <- as.data.frame(datExpr))
  cat("\t", paste("Input has expression data for", nrow(datExpr1), "Cells and", ncol(datExpr1), "Genes", sep=" "), "\n")

  ## Data filtering
  cat("\t", "Filtering data...", "\n")
  ### Count number of expressed genes per cell
  geneExpStat <- as.data.frame(apply(datExpr1, 1, function(x) { table( x >= expcutoff )["TRUE"] } ))
  names(geneExpStat) <- "GenesPerCells"
  geneExpStat[is.na(geneExpStat)] <- 0
  ### Plot a histogram for number of expressed genes per cell
  validateD_plot1 <- ggplot(geneExpStat, aes(GenesPerCells)) + geom_histogram(colour = "black", fill = "grey", bins = 20) + xlim(0,max(geneExpStat[,1])) + theme_bw() + labs(title="Expressed Genes per Cell", x="Number of Genes", y="Number of Cells")
  ggsave(file=paste(outprefix,"histogram_genes_per_cell.pdf", sep="_"), plot=validateD_plot1, width=6, height=4)
  ### Remove cells with no gene(s) expressed (RPKM < 0.5)
  datExpr2 <- datExpr1[geneExpStat > 0,]
  cat("\t", "\t", paste("Removed", nrow(datExpr2) - nrow(datExpr1), "cell(s) with no gene(s) expressed", sep=" "), "\n")
  ### Count how many cells each gene is expressed in
  cellsPerGene <- as.data.frame(apply(datExpr2, 2, function(x) { table( x >= expcutoff )["TRUE"] } ))
  names(cellsPerGene) <- "CellsPerGene"
  cellsPerGene[is.na(cellsPerGene)] <- 0
  ### Remove genes that are not expressed in any cell (RPKM < 0.5)
  datExpr3 <- datExpr2[,cellsPerGene > 0]
  cat("\t", "\t", paste("Removed", ncol(datExpr2) - ncol(datExpr3), "gene(s) with no expression in at least one cell", sep=" "), "\n")
  cat("\t", "Finished filtering data...", "\n")

  ## saving RData and return filtered data matrix
  save(datExpr, datExpr3, file="validatedata.RData")
  return(datExpr3)
  cat("\t", "RData file saved...", "\n")
}
