# clustercells
# This script will
# - read the filtered data
# - log transforms the data
# - run 3D tSNE with input parmeters
# - runs affinity propagation
# - runs k-means based on ap optimal clusters
# - joins cluster information, X, Y, Z, filtered expression data
# - generates a 3D scatter plot for visualization
# - returns new data matrix
#
# Build and Reload Package:  'Cmd + Shift + B'
# Check Package:             'Cmd + Shift + E'
# Test Package:              'Cmd + Shift + T'
# R --max-ppsize 500000

clustercells <- function(filtereddata, outprefix, mymax_iter)
{
  cat("===> Resolving single cells...", "\n")

  ## Loading packages
  suppressPackageStartupMessages({
    library(ggplot2)
    library(Rtsne)
    library(apcluster, quietly = TRUE)
    library(randomcoloR)
    library(plot3D)
    library(rgl)
  })
  set.seed(50)

  ## Loading previously saved RData and set input parameters
  #lnames1 <- load("validatedata.RData")
  #mymax_iter = 1000
  mydims = 3
  mytheta = 0.0
  myinitial_dims = 50


  ## Log transforming the data
  expData1 <- log2(filtereddata+1)

  ## Running 3D tSNE to cluster cells
  cat("\t", "Resolving cells into 3-D space...", "\n")
  rtsne3d <- Rtsne(expData1, dims=mydims, pca=TRUE, check_duplicates=FALSE, max_iter=mymax_iter, theta=mytheta, initial_dims=myinitial_dims, verbose=FALSE)

  ## Running Affinity Propagation Clustering to identify optimal number of clusters
  cat("\t", "Identifying optimal number of clusters...", "\n")
  clusterdata <- rtsne3d$Y
  apclus <- apcluster(negDistMat(r=2), clusterdata)
  cat("\t", "\t", "Optimal number of clusters for this data:", length(apclus@clusters), "\n")
  optimalclusters <- length(apclus@clusters)

  ## Running k-means clustering to assign cluster labels
  cat("\t", "Assigning cluster labels...", "\n")
  km_rtsne3d <- kmeans(clusterdata, centers=optimalclusters, iter.max=10000)
  expData2 <- as.data.frame(cbind(km_rtsne3d$cluster, clusterdata))
  names(expData2) <- c("Cluster", "X", "Y", "Z")
  expData3 <- cbind(expData2, expData1)
  expData4 <- expData3[order(expData3[,1], decreasing=F),]
  cat("\t", "Finished resolving cells into 3-D space...", "\n")

  ## Plotting clustered cells into 3-D scatter plot
  cat("\t", "Plotting resolved cells into 3-D space...", "\n")
  colpalette <- distinctColorPalette(optimalclusters)
  pdf(paste(outprefix,"scatterplot_cells.pdf", sep="_"), width=6, height=6)
  scatter3D(expData4[,2], expData4[,3], expData4[,4], colvar=expData4[,1], pch=20, main="Clusters", col=colpalette[1:max(optimalclusters)], cex=1.5, theta=45, phi=10)
  dev.off()

  ## Plotting barchart for cells per cluster
  clusterinfo<-as.data.frame(table(expData4[,1]))
  names(clusterinfo)<-c("Cluster", "Cells")
  plotbar<-ggplot(clusterinfo, aes(x=Cluster, y=Cells)) + geom_bar(stat="identity", fill=colpalette) + theme_bw() + labs(title="Number of Cells per Cluster", x="Clusters", y="Number of Cells")
  ggsave(file=paste(outprefix,"barplot_cells_per_cluster.pdf", sep="_"), plot=plotbar, width=7, height=5)

  ## saving RData and return filtered data matrix
  save(expData1, rtsne3d, optimalclusters, expData4, colpalette, file="clustercells.RData")
  return(expData4)
  cat("\t", "RData file saved...", "\n")
}

