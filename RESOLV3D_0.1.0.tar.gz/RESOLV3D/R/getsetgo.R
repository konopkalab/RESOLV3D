# getsetgo
# This script will
# - fetch the top10 GO terms for list of input genes
# - uses Probability Weighting Function
# - uses Wallenius approximation to identify GO
# - uses B&H method for P-val <= 0.05
#
# Build and Reload Package:  'Cmd + Shift + B'
# Check Package:             'Cmd + Shift + E'
# Test Package:              'Cmd + Shift + T'
# R --max-ppsize 500000

getsetgo <- function(genesfn, allgenesfn, outprefix, genome, keytype)
{
  ## Loading packages
  suppressPackageStartupMessages({
    library(goseq)
    library(GO.db)
  })

  all_genes <- scan(allgenesfn, what="")
  genelist <- scan(genesfn, what="")

  ## creating a background genes model
  gene.vector <- as.integer(all_genes %in% genelist)
  names(gene.vector) <- all_genes
  #supportedOrganisms()

  ## Fitting the Probability Weighting Function (PWF)
  pwf <- nullp(gene.vector, genome, keytype, plot.fit=FALSE)

  ## Identify GO terms using the Wallenius approximation
  GOwall <- goseq(pwf, genome, keytype)

  ## Identify enriched GO terms using B&H method for P-val
  p_adj_BH <- p.adjust(GOwall$over_represented_pvalue, method="BH")

  ## Filter GO terms for adj p-val <= 0.05
  GOwallBH <- cbind(GOwall, p_adj_BH)
  GOwallBHsig <- GOwallBH
  #GOwallBHsig <- GOwallBH[GOwallBH$p_adj_BH <= 0.05,]
  GOwallBHsig1 <- GOwallBHsig[,c(7, 1, 6, 4, 5, 8)]
  GOwallBHsig2 <- GOwallBHsig1[order(GOwallBHsig1$p_adj_BH, decreasing=F),]
  colnames(GOwallBHsig2) <- c("Category", "GO_ID", "GO_Term", "Number_of_Input_Genes", "Number_of_Total_Genes", "Adj_p-value_BH")

  #enrichedGO=GOwall$category[p.adjust(GOwall$over_represented_pvalue, method="BH") <= 0.05]

  ## Print GO definition for top 10 enriched GO terms
  #for(go in enrichedGO)
  #  {
  #  print(GOTERM[[go]])
  #  cat("--------------------------------------\n")
  #  }

  ## Return GO Terms
  return(GOwallBHsig2)
}
