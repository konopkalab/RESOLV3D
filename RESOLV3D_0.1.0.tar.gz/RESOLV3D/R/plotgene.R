# plotgene
# This script will
# - highlight gene of interest among the clusters plotted on a 3D scatter plot
# - plot a barplot for all clusters with gene of interest expression level
#
# Build and Reload Package:  'Cmd + Shift + B'
# Check Package:             'Cmd + Shift + E'
# Test Package:              'Cmd + Shift + T'
# R --max-ppsize 500000

plotgene <- function(genename, outprefix)
{
  cat("===> Creating plot for gene:", genename ,"...", "\n")
  ## Loading packages
  suppressPackageStartupMessages({
    library(ggplot2)
    library(randomcoloR)
    library(plot3D)
    library(rgl)
  })

  ## Loading previously saved RData
  load("clustercells.RData")

  ## Extracting data for gene of interest
  dataMain <- cbind(expData4[,c(1:4)], expData4[,as.character(genename)])
  names(dataMain) <- c("Cluster", "X", "Y", "Z", as.character(genename))

  ## Rearranging table to match colors
  clusterFreq <- as.data.frame(table(dataMain[,1]))
  colbar <- NULL
  for(n in 1:nrow(clusterFreq))
  {
    ntemp <- rep(clusterFreq[n,1], clusterFreq[n,2])
    colbar <- c(colbar, ntemp)
  }

  ## Creating a violin plot for gene of interest
  p1 <- ggplot(dataMain, aes(factor(dataMain[,1]), dataMain[,as.character(genename)], fill=factor(dataMain[,1]))) + geom_violin(scale="width") + geom_jitter() + scale_fill_manual(values=colpalette) + theme(panel.background=element_blank(), axis.line.x=element_line(colour="black"), axis.line.y=element_line(colour="black")) + labs(title=as.character(genename), x="Clusters", y="Log2 (Expression)") + labs(fill="Clusters")
  ggsave(filename=paste(outprefix, "_vlnplot_", as.character(genename), ".pdf", sep=""), plot=p1, width=6, height=4, units="in")

  ## Creating a bar plot for gene of interest
  p2 <- ggplot(dataMain, aes(x=1:nrow(dataMain), y=dataMain[,as.character(genename)])) + geom_bar(stat="identity", fill=colpalette[colbar]) + theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background=element_blank(), axis.line.x=element_line(colour="black"), axis.line.y=element_line(colour="black")) + labs(title=as.character(genename), x="Cells by Clusters", y="Log2 (Expression)")
  ggsave(filename=paste(outprefix, "_barplot_", as.character(genename), ".pdf", sep=""), plot=p2, width=6, height=4, units="in")

  ## Creating a 3D scatter plot for gene of interest
  pdf(paste(outprefix, "_3Dscatterplot_", as.character(genename), ".pdf", sep=""), width=6, height=6)
  scatter3D(dataMain[,2], dataMain[,3], dataMain[,4], colvar=dataMain[,as.character(genename)], pch=20, main=as.character(genename), cex=1.5, theta=45, phi=10)
  dev.off()

  cat("Finished...", "\n")
}
